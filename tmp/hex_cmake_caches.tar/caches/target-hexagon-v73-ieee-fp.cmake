set(OPTFLAGS "${OPTFLAGS} -mv73 -mhvx=v73 -mhvx-ieee-fp")
set(OPTFLAGS "${OPTFLAGS} -O2 -ffp-contract=off")
set(OPTFLAGS "${OPTFLAGS} -mmemops -mnvj -mnvs")

set(CMAKE_C_FLAGS_RELEASE "${OPTFLAGS}" CACHE STRING "")
set(CMAKE_CXX_FLAGS_RELEASE "${OPTFLAGS}" CACHE STRING "")
set(CMAKE_BUILD_TYPE "Release" CACHE STRING "")
