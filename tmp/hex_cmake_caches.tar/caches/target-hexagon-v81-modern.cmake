set(OPTFLAGS "${OPTFLAGS} -mv81 -mhvx=v81 -mhvx-length=128b")
set(OPTFLAGS "${OPTFLAGS} -O3 -fvectorize")
set(OPTFLAGS "${OPTFLAGS} -mcabac")
#set(OPTFLAGS "${OPTFLAGS} -mmemops -mnvj -mnvs -mcabac")

set(CMAKE_C_FLAGS_RELEASE "${OPTFLAGS}" CACHE STRING "")
set(CMAKE_CXX_FLAGS_RELEASE "${OPTFLAGS}" CACHE STRING "")
set(CMAKE_BUILD_TYPE "Release" CACHE STRING "")
